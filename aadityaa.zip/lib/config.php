<?php
$user = "pudtraa7x";
$pass = "meiputrayana45";
$r_male = "1";
$r_female = "2";
$max_status = "1000";
?>